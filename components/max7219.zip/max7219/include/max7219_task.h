#include <stdint.h>
#include <stdio.h>

void start_max7219_task(int slot_num);
